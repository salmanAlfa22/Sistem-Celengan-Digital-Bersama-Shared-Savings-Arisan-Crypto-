const { ethers } = require("hardhat");

async function main() {
  const setoran = ethers.parseEther("0.01"); // setoran per ronde
  const maxPeserta = 5;
  const durasiRonde = 7 * 24 * 60 * 60; // 7 hari

  const Arisan = await ethers.getContractFactory("ArisanCrypto");
  const arisan = await Arisan.deploy(setoran, maxPeserta, durasiRonde);
  await arisan.waitForDeployment();

  console.log("ArisanCrypto deployed ke:", await arisan.getAddress());
  console.log("Jaminan per peserta     :", ethers.formatEther(await arisan.requiredCollateral()), "ETH");
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
