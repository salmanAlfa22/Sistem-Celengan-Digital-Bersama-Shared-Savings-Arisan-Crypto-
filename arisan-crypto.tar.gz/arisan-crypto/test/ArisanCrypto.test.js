const { expect } = require("chai");
const { ethers } = require("hardhat");
const { time } = require("@nomicfoundation/hardhat-network-helpers");

describe("ArisanCrypto", function () {
  const SETORAN = ethers.parseEther("1");
  const MAX = 3;
  const DURASI = 24 * 60 * 60; // 1 hari
  const JAMINAN = SETORAN * BigInt(MAX - 1);

  let arisan, a, b, c, outsider;

  beforeEach(async () => {
    [a, b, c, outsider] = await ethers.getSigners();
    const F = await ethers.getContractFactory("ArisanCrypto");
    arisan = await F.deploy(SETORAN, MAX, DURASI);
  });

  async function joinAll() {
    for (const s of [a, b, c]) await arisan.connect(s).join({ value: JAMINAN });
  }

  it("auto-start saat kuota penuh", async () => {
    await arisan.connect(a).join({ value: JAMINAN });
    expect(await arisan.status()).to.equal(0);
    await arisan.connect(b).join({ value: JAMINAN });
    await arisan.connect(c).join({ value: JAMINAN });
    expect(await arisan.status()).to.equal(1);
  });

  it("menolak jaminan salah & double join", async () => {
    await expect(arisan.join({ value: 1n })).to.be.revertedWith("Jaminan tidak sesuai");
    await arisan.join({ value: JAMINAN });
    await expect(arisan.join({ value: JAMINAN })).to.be.revertedWith("Sudah terdaftar");
  });

  it("peserta bisa leave sebelum mulai dan dapat refund", async () => {
    await arisan.connect(a).join({ value: JAMINAN });
    await arisan.connect(b).join({ value: JAMINAN });
    await expect(arisan.connect(a).leave()).to.changeEtherBalance(a, JAMINAN);
    expect(await arisan.memberCount()).to.equal(1);
  });

  it("alur sukses: semua bayar, 3 ronde, semua dapat giliran", async () => {
    await joinAll();
    const signers = [a, b, c];
    for (let r = 0; r < MAX; r++) {
      for (const s of signers) await arisan.connect(s).contribute({ value: SETORAN });
      await expect(arisan.closeRound())
        .to.emit(arisan, "RoundClosed")
        .withArgs(r, signers[r].address, SETORAN * 3n);
      await expect(arisan.connect(signers[r]).withdraw()).to.changeEtherBalance(
        signers[r],
        SETORAN * 3n
      );
    }
    expect(await arisan.status()).to.equal(2);
    for (const s of signers)
      await expect(arisan.connect(s).withdrawCollateral()).to.changeEtherBalance(s, JAMINAN);
  });

  it("tidak bisa tutup ronde sebelum semua bayar / deadline", async () => {
    await joinAll();
    await arisan.connect(a).contribute({ value: SETORAN });
    await expect(arisan.closeRound()).to.be.revertedWith("Ronde belum bisa ditutup");
  });

  it("menolak non-peserta, nominal salah, dan bayar dua kali", async () => {
    await joinAll();
    await expect(arisan.connect(outsider).contribute({ value: SETORAN })).to.be.revertedWith("Bukan peserta");
    await expect(arisan.connect(a).contribute({ value: 1n })).to.be.revertedWith("Nominal salah");
    await arisan.connect(a).contribute({ value: SETORAN });
    await expect(arisan.connect(a).contribute({ value: SETORAN })).to.be.revertedWith("Sudah bayar ronde ini");
  });

  it("penunggak ditalangi jaminan & statusnya terkunci", async () => {
    await joinAll();
    await arisan.connect(a).contribute({ value: SETORAN });
    await arisan.connect(b).contribute({ value: SETORAN });
    await time.increase(DURASI + 1);
    await expect(arisan.closeRound()).to.emit(arisan, "Covered").withArgs(0, c.address, SETORAN);
    expect(await arisan.collateral(c.address)).to.equal(JAMINAN - SETORAN);
    await expect(arisan.connect(a).withdraw()).to.changeEtherBalance(a, SETORAN * 3n);
    expect(await arisan.hasDefaulted(c.address)).to.equal(true);
  });

  it("skenario terburuk: peserta tidak pernah bayar, kontrak tetap solvent", async () => {
    await joinAll();
    for (let r = 0; r < MAX; r++) {
      await arisan.connect(a).contribute({ value: SETORAN });
      await arisan.connect(b).contribute({ value: SETORAN });
      await time.increase(DURASI + 1);
      await arisan.closeRound(); // c tidak pernah bayar
    }
    expect(await arisan.status()).to.equal(2);

    let owed = 0n;
    for (const s of [a, b, c]) owed += (await arisan.pendingWithdrawals(s.address)) + (await arisan.collateral(s.address));
    const bal = await ethers.provider.getBalance(await arisan.getAddress());
    expect(owed).to.be.lte(bal);

    for (const s of [a, b, c]) {
      if ((await arisan.pendingWithdrawals(s.address)) > 0n) await arisan.connect(s).withdraw();
      if ((await arisan.collateral(s.address)) > 0n) await arisan.connect(s).withdrawCollateral();
    }
  });
});
