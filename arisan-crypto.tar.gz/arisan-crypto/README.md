# Arisan Crypto: Celengan Digital Bersama (Solidity)

Smart contract arisan tanpa perantara. Sekelompok orang menyetor nominal tetap tiap ronde,
dan satu orang menerima seluruh dana (giliran sesuai urutan join).

## Konsep

| Istilah | Arti |
|---|---|
| Setoran | Nominal tetap tiap ronde (mis. 0.01 ETH) |
| Jaminan | Deposit awal = setoran x (jumlah peserta - 1), untuk menalangi jika ada yang menunggak |
| Ronde | Satu periode setoran, berakhir saat semua bayar atau deadline lewat |
| Hadiah | setoran x jumlah peserta, diterima pemenang ronde |

Alur: `join()` -> (kuota penuh, otomatis mulai) -> `contribute()` -> `closeRound()` -> `withdraw()` -> ... -> `withdrawCollateral()`

## Langkah 1: Prasyarat
- Node.js 18+ (cek `node -v`)
- Editor (VS Code + ekstensi Solidity)

## Langkah 2: Setup
```bash
npm install
```

## Langkah 3: Pahami kontrak (`contracts/ArisanCrypto.sol`)
1. **State**: `members[]` menyimpan urutan giliran, `collateral`, `pendingWithdrawals`, `hasPaid[ronde][alamat]`.
2. **join()**: validasi jaminan, daftarkan peserta, auto-start saat penuh.
3. **contribute()**: validasi nominal, deadline, dan cegah bayar dua kali.
4. **closeRound()**: siapa saja bisa memanggil. Hadiah dikreditkan ke pemenang, penunggak ditalangi dari jaminan.
5. **withdraw()**: pola *pull payment* (penerima menarik sendiri) + *checks-effects-interactions* untuk mencegah reentrancy.

## Langkah 4: Jalankan test
```bash
npx hardhat test
```

## Langkah 5: Deploy ke jaringan lokal
Terminal 1:
```bash
npx hardhat node
```
Terminal 2:
```bash
npm run deploy:local
```
Ubah `setoran`, `maxPeserta`, `durasiRonde` di `scripts/deploy.js` sesuai kebutuhan.

## Langkah 6: Deploy ke testnet (Sepolia)
1. Buat wallet khusus testnet, minta ETH gratis dari faucet Sepolia.
2. Buat akun RPC (Alchemy/Infura) dan ambil URL-nya.
3. Tambahkan ke `hardhat.config.js`:
```js
require("dotenv").config(); // npm i dotenv
module.exports = {
  solidity: "0.8.24",
  networks: {
    sepolia: {
      url: process.env.SEPOLIA_RPC_URL,
      accounts: [process.env.PRIVATE_KEY],
    },
  },
};
```
4. File `.env` (JANGAN di-commit, tambahkan ke `.gitignore`):
```
SEPOLIA_RPC_URL=https://...
PRIVATE_KEY=0x...
```
5. Deploy: `npx hardhat run scripts/deploy.js --network sepolia`

## Langkah 7: Coba interaksi lewat console
```bash
npx hardhat console --network localhost
```
```js
const [a,b,c] = await ethers.getSigners();
const arisan = await ethers.getContractAt("ArisanCrypto", "ALAMAT_KONTRAK");
const j = await arisan.requiredCollateral();
await arisan.connect(a).join({ value: j });
await arisan.connect(b).join({ value: j });
```

## Pengembangan lanjutan
- **Pemenang acak**: Chainlink VRF (saat ini urutan join, supaya deterministik).
- **Token stablecoin**: ganti ETH dengan ERC-20 (USDC/IDRX) via `SafeERC20`.
- **Factory contract**: satu kontrak untuk membuat banyak grup arisan.
- **Frontend**: React + ethers.js / wagmi untuk antarmuka dompet.
- **Audit & fuzz test**: Foundry/Echidna sebelum dipakai uang sungguhan.

## Peringatan
Project edukasi. Jangan dipakai dengan dana nyata tanpa audit keamanan.
